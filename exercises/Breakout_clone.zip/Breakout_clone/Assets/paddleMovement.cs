﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class paddleMovement : MonoBehaviour
{
    public KeyCode rightKey;
    public KeyCode leftKey;
    public float paddleSpeed;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(rightKey) && transform.position.x<8.2f)
        {
            transform.position = new Vector3(transform.position.x+paddleSpeed, transform.position.y, 0);
        }
        if (Input.GetKey(leftKey) && transform.position.x > -8f)
        {
            transform.position = new Vector3(transform.position.x-paddleSpeed, transform.position.y, 0);
        }
    }
}
