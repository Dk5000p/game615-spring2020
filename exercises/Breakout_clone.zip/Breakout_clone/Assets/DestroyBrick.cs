﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class DestroyBrick : MonoBehaviour
{
    // Start is called before the first frame update
    public float score;
    public Text scoreDisplay;
    public float balls;
    public Text ballDisplay;
    public int scene;
    public AudioSource boing;
    void LaunchBall()
    {
        float force_x = Random.Range(-0.6f,0.5f);
        float force_y = Random.Range(-0.6f, -0.5f);
        Vector3 force = new Vector3(force_x, force_y, 0);
        float magnitude = 500f;
        GetComponent<Rigidbody2D>().velocity = new Vector3(0, 0, 0);
        GetComponent<Rigidbody2D>().AddForce(force * magnitude);
    }
    void Start()
    {
        score = 0;
        balls = 3;
    }

    // Update is called once per frame
    void Update()
    {
        scoreDisplay.text = score.ToString();
        ballDisplay.text = "Balls: " + balls.ToString();
        if (Input.GetKeyDown(KeyCode.Space))
        {
            LaunchBall();
        }
        if (balls <= 0)
        {
            SceneManager.LoadScene(scene);
        }
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Brick")
        {
            Destroy(collision.gameObject);
            boing.Play();
            score += 10;
        }
        if (collision.gameObject.tag == "Loss")
        {
            GetComponent<Rigidbody2D>().velocity = new Vector3(0, 0, 0);
            transform.position = new Vector3(0, -2, 0);
            balls -= 1;
        }
    }
}
