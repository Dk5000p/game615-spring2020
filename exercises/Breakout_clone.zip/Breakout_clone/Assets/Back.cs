﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Back : MonoBehaviour
{
    public SpriteRenderer s;
    // Start is called before the first frame update
    void Start()
    {
        s = GetComponent<SpriteRenderer>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnMouseEnter()
    {
        s.color = Color.green;
    }
    private void OnMouseExit()
    {
        s.color = Color.black;

    }
    private void OnMouseDown()
    {
        SceneManager.LoadScene(0);
    }
}
